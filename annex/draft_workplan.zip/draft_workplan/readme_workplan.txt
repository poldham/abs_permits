The draft workplan is available as: 

.csv for import into Excel or Open Office Calc
.xlxs. for Excel
.xml for import to Microsoft Project
.oplx for Omni Plan
.pdf for printing 

Delete columns that are not required. 

Generated in OmniPlan. 