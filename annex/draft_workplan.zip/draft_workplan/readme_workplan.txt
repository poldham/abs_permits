The draft workplan is available as: 

.csv for import into Excel or Open Office Calc
.xml for import to Microsoft Project
.oplx for Omni Plan
.pdf for printing 